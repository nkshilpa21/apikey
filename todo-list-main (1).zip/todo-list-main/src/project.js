function Project(id, name, tasks) {
  this.id = id;
  this.name = name;
  this.tasks = tasks;
}

export { Project };
